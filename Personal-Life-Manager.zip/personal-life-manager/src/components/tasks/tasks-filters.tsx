'use client'

export function TasksFilters() {
  return (
    <div className="p-4">
      <div className="text-center text-gray-500">
        Tasks filters coming soon...
      </div>
    </div>
  )
}
