'use client'

import { Card } from '@/components/ui/card'

export function TasksList() {
  return (
    <Card>
      <div className="p-4">
        <div className="text-center text-gray-500">
          Tasks list view coming soon...
        </div>
      </div>
    </Card>
  )
}
